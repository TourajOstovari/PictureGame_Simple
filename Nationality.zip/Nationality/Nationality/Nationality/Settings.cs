﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nationality
{
    public partial class Settings : Form
    {
        public Settings()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (System.IO.File.Exists(textBox2.Text))
            {
                Model.ImagesInfo img = new Model.ImagesInfo();
                img.Natio = textBox1.Text;
                img.ImgAddress = textBox2.Text;
                Model.Info_Container.Container.Add(img);
                dataGridView1.Rows.Add(textBox1.Text, textBox2.Text);
            }
            else
            {
                MessageBox.Show("Error! This file is not available... ","Error!!!",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
                        
        }
    }
}
