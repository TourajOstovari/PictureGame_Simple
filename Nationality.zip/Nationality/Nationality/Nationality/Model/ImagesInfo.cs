﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nationality.Model
{
    public class ImagesInfo
    {
        public string Natio { get; set; }
        public string ImgAddress { get; set; }   
    }
    public class Info_Container
    {
        public static System.Collections.Generic.List<ImagesInfo> Container = new List<ImagesInfo>();
        public Info_Container()
        {
            
        }
        
    }
}
