﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nationality
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new Settings().ShowDialog();
            //pictureBox1.Image = Image.FromFile(@"C:\\usa.jpg");
        }
        bool CanI = false;
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
        int index = 0;
        private void button6_Click(object sender, EventArgs e)
        {
            CanI = true;
            counter_timer = 3;
            Random r = new Random();
            index = r.Next(0, Model.Info_Container.Container.Count);
            pictureBox1.Image = Image.FromFile(Model.Info_Container.Container[index].ImgAddress);
            timer1.Enabled = true;
            timer2.Enabled = true;
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            timer2.Enabled = false;
        }
        int opacity = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y + 25);
            System.Threading.Thread.Sleep(450);
            if (opacity < 255)
            {
                Image img = pictureBox1.Image;
                using (Graphics g = Graphics.FromImage(img))
                {
                    Pen pen = new Pen(Color.FromArgb(opacity, 255, 255, 255), img.Width);
                    g.DrawLine(pen, -10, -10, img.Width, img.Height);
                    g.Save();
                }
                pictureBox1.Image = img;
                opacity+=50;
            }
            else
            {
                timer1.Stop();
                pictureBox1.Location = new Point(242, 40);
                opacity = 0;
            }
        }
        int counter_timer = 3;
        int score = 0;
        private void timer2_Tick(object sender, EventArgs e)
        {
            label2.Text = counter_timer.ToString();
            counter_timer--;
            if(counter_timer == 0)
            {
                MessageBox.Show("Time is over... your score: " + score);
                timer1.Enabled = false;
                timer2.Enabled = false;
                counter_timer = 3;
                pictureBox1.Location = new Point(242, 40);
                pictureBox1.Image = null;
                CanI = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Model.Info_Container.Container[index].Natio.Contains("Japanese") && CanI) { score += 20; MessageBox.Show("You are right ... your score is: " + score); } else if (CanI) { score -= 5; MessageBox.Show("You are wrong ... your score is: " + score); }
            timer2.Enabled = false;
            timer1.Enabled = false;
            pictureBox1.Location = new Point(242, 40);
            if (CanI) CanI = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Model.Info_Container.Container[index].Natio.Contains("Chinese") && CanI) { score += 20; MessageBox.Show("You are right ... your score is: " + score); } else if (CanI) { score -= 5; MessageBox.Show("You are wrong ... your score is: " + score); }
            timer2.Enabled = false;
            timer1.Enabled = false;
            pictureBox1.Location = new Point(242, 40);
            if (CanI) CanI = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Model.Info_Container.Container[index].Natio.Contains("Korean") && CanI) { score += 20; MessageBox.Show("You are right ... your score is: " + score); } else if (CanI) { score -= 5; MessageBox.Show("You are wrong ... your score is: " + score); }
            timer2.Enabled = false;
            timer1.Enabled = false;
            pictureBox1.Location = new Point(242, 40);
            if (CanI) CanI = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (Model.Info_Container.Container[index].Natio.Contains("Thai") && CanI) { score += 20; MessageBox.Show("You are right ... your score is: " + score); } else if(CanI) { score -= 5; MessageBox.Show("You are wrong ... your score is: " + score); }
            timer2.Enabled = false;
            timer1.Enabled = false;
            pictureBox1.Location = new Point(242, 40);
            if (CanI) CanI = false;

        }
    }
}
